# Wget-NextJS-v1

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/SecteurA/Wget-NextJS-v1)